import { useMemo } from "react";
import {
  computeManifoldMetrics,
  getMetricHealth,
  METRIC_HEALTHY_RANGES,
  type ManifoldMetrics,
  type MetricHealth,
} from "@/domain/content/manifoldMetrics";
import { ZONE_CONFIDENCE_ORDER, RELATED_ZONE_JUMPS } from "@/features/explorer/navigation/useExplorerNavigation";
import { useLearnedManifold } from "@/features/learning/useLearnedManifold";
import { parsePairKey } from "@/features/learning/hebbianAdapter";
import { useLearningStore } from "@/features/learning/useLearningStore";

const HEALTH_COLOR: Record<MetricHealth, string> = {
  healthy:    "#4ade80",
  "warn-low": "#facc15",
  "warn-high":"#fb923c",
  critical:   "#f87171",
};

const HEALTH_LABEL: Record<MetricHealth, string> = {
  healthy:    "healthy",
  "warn-low": "low",
  "warn-high":"high",
  critical:   "critical",
};

type MetricKey = keyof Omit<ManifoldMetrics, "zoneConfidenceCentroids">;

const METRIC_META: Array<{
  key: MetricKey;
  label: string;
  description: string;
  format: (v: number) => string;
}> = [
  {
    key: "couplingTensorDensity",
    label: "Coupling Tensor Density",
    description: "ORGANELLE_SUBSTRATE_LINKS / (organelles × substrates). Below 10 % = underlinked; above 25 % = overcoupled.",
    format: (v) => `${(v * 100).toFixed(1)}%`,
  },
  {
    key: "couplingTensorLinks",
    label: "Coupling Tensor Links",
    description: "Raw count of ORGANELLE_SUBSTRATE_LINKS entries.",
    format: (v) => String(v),
  },
  {
    key: "meanZoneConfidence",
    label: "Mean Zone Confidence",
    description: "Average confidence centroid σ̄ across all 8 zones. Dropping centroid = adding unconfirmed claims.",
    format: (v) => v.toFixed(3),
  },
  {
    key: "biophotonCoverage",
    label: "Biophoton Coverage",
    description: "BIOPHOTON_LINKS / organelles². Above 5 % = links no longer selective.",
    format: (v) => `${(v * 100).toFixed(2)}%`,
  },
  {
    key: "biophotonLinks",
    label: "Biophoton Links",
    description: "Raw count of BIOPHOTON_LINKS entries.",
    format: (v) => String(v),
  },
  {
    key: "qiTensorDensity",
    label: "QI Tensor Density",
    description: "QI_INTERSECTIONS / (8 × 3 × 11). Below 5 % = too sparse; above 10 % = losing selectivity.",
    format: (v) => `${(v * 100).toFixed(1)}%`,
  },
  {
    key: "qiTensorLinks",
    label: "QI Tensor Entries",
    description: "Raw count of QI_INTERSECTIONS entries.",
    format: (v) => String(v),
  },
  {
    key: "exportRankTotal",
    label: "Export Rank Total",
    description: "Sum of exported symbols across all modules. Rapid growth = type proliferation / leaky abstractions.",
    format: (v) => String(v),
  },
  {
    key: "phaseTransitionCount",
    label: "Phase Transitions",
    description: "Count of discrete state-jump types. Each new transition = a new UX mode requiring justification.",
    format: (v) => String(v),
  },
];

function MetricRow({
  label,
  description,
  value,
  formatted,
  health,
  range,
}: {
  label: string;
  description: string;
  value: number;
  formatted: string;
  health: MetricHealth;
  range: { low: number; high: number };
}) {
  const color = HEALTH_COLOR[health];
  return (
    <div
      style={{
        borderLeft: `3px solid ${color}`,
        paddingLeft: "1rem",
        marginBottom: "1.5rem",
      }}
    >
      <div style={{ display: "flex", alignItems: "baseline", gap: "0.75rem", marginBottom: "0.25rem" }}>
        <span style={{ fontSize: "1.05rem", fontWeight: 600, color: "#e2e8f0" }}>{label}</span>
        <span style={{ fontSize: "1.4rem", fontWeight: 700, color, fontVariantNumeric: "tabular-nums" }}>
          {formatted}
        </span>
        <span
          style={{
            fontSize: "0.7rem",
            textTransform: "uppercase",
            letterSpacing: "0.08em",
            color,
            opacity: 0.85,
            border: `1px solid ${color}`,
            borderRadius: "3px",
            padding: "1px 5px",
          }}
        >
          {HEALTH_LABEL[health]}
        </span>
      </div>
      <p style={{ fontSize: "0.78rem", color: "#94a3b8", margin: "0 0 0.25rem" }}>{description}</p>
      <span style={{ fontSize: "0.72rem", color: "#64748b" }}>
        healthy range: {range.low} – {range.high}
      </span>
    </div>
  );
}

export default function Metrics() {
  const m      = useMemo(() => computeManifoldMetrics(), []);
  const lm     = useLearnedManifold();
  const reset  = useLearningStore((s) => s.reset);

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#020817",
        color: "#e2e8f0",
        fontFamily: "'Inter', system-ui, sans-serif",
        padding: "2rem 1.5rem",
        maxWidth: "820px",
        margin: "0 auto",
      }}
    >
      <div style={{ marginBottom: "2.5rem" }}>
        <div style={{ fontSize: "0.7rem", textTransform: "uppercase", letterSpacing: "0.1em", color: "#475569", marginBottom: "0.4rem" }}>
          developer surface · Cell OS manifold
        </div>
        <h1 style={{ fontSize: "1.8rem", fontWeight: 700, color: "#f1f5f9", margin: "0 0 0.5rem" }}>
          Manifold Health Metrics
        </h1>
        <p style={{ fontSize: "0.85rem", color: "#64748b", margin: 0 }}>
          Live tensor field statistics computed from the source arrays.
          See <code style={{ color: "#94a3b8" }}>MANIFOLD_ANALYSIS.md §11.8</code> for interpretation.
        </p>
      </div>

      <section style={{ marginBottom: "3rem" }}>
        <h2 style={{ fontSize: "0.75rem", textTransform: "uppercase", letterSpacing: "0.1em", color: "#475569", marginBottom: "1.25rem" }}>
          Tensor Field Metrics
        </h2>
        {METRIC_META.map(({ key, label, description, format }) => {
          const value = m[key] as number;
          const health = getMetricHealth(key, value);
          return (
            <MetricRow
              key={key}
              label={label}
              description={description}
              value={value}
              formatted={format(value)}
              health={health}
              range={METRIC_HEALTHY_RANGES[key]}
            />
          );
        })}
      </section>

      <section style={{ marginBottom: "3rem" }}>
        <h2 style={{ fontSize: "0.75rem", textTransform: "uppercase", letterSpacing: "0.1em", color: "#475569", marginBottom: "1.25rem" }}>
          Zone Confidence Centroids (σ̄)
        </h2>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(180px, 1fr))", gap: "0.75rem" }}>
          {(Object.entries(m.zoneConfidenceCentroids) as [string, number][]).map(([zone, sigma]) => {
            const color = sigma >= 1.0 ? "#4ade80" : sigma >= 0.5 ? "#facc15" : "#f87171";
            const isConfidenceFirst = ZONE_CONFIDENCE_ORDER.includes(zone as any) &&
              ZONE_CONFIDENCE_ORDER.indexOf(zone as any) < 5;
            return (
              <div
                key={zone}
                style={{
                  background: "#0f172a",
                  border: `1px solid ${color}22`,
                  borderRadius: "6px",
                  padding: "0.65rem 0.85rem",
                }}
              >
                <div style={{ fontSize: "0.72rem", color: "#64748b", marginBottom: "0.25rem", display: "flex", justifyContent: "space-between" }}>
                  <span>{zone}</span>
                  {isConfidenceFirst && (
                    <span style={{ color: "#4ade80", fontSize: "0.65rem" }}>evidence-first</span>
                  )}
                </div>
                <div style={{ fontSize: "1.3rem", fontWeight: 700, color, fontVariantNumeric: "tabular-nums" }}>
                  {sigma.toFixed(1)}
                </div>
              </div>
            );
          })}
        </div>
      </section>

      <section style={{ marginBottom: "3rem" }}>
        <h2 style={{ fontSize: "0.75rem", textTransform: "uppercase", letterSpacing: "0.1em", color: "#475569", marginBottom: "1.25rem" }}>
          Geodesic Zone Jumps
        </h2>
        <p style={{ fontSize: "0.78rem", color: "#64748b", marginBottom: "1rem" }}>
          Non-sequential zone pairs with reduced effective distance in the biophoton-corrected metric g<sub>ij</sub>.
          See MANIFOLD_ANALYSIS.md §11.3.
        </p>
        {RELATED_ZONE_JUMPS.map(([a, b]) => (
          <div
            key={`${a}-${b}`}
            style={{
              display: "flex",
              alignItems: "center",
              gap: "0.75rem",
              background: "#0f172a",
              border: "1px solid #1e3a5f",
              borderRadius: "6px",
              padding: "0.65rem 1rem",
              marginBottom: "0.5rem",
              fontSize: "0.85rem",
            }}
          >
            <span style={{ color: "#7dd3fc", fontWeight: 600 }}>{a}</span>
            <span style={{ color: "#475569" }}>↔</span>
            <span style={{ color: "#7dd3fc", fontWeight: 600 }}>{b}</span>
            <span style={{ color: "#475569", marginLeft: "auto", fontSize: "0.72rem" }}>
              {a === "nucleus" && b === "mitochondria" ? "d_g = 3.45 (graph: 4)" : "d_g = 0.84 (biophoton coupled)"}
            </span>
          </div>
        ))}
      </section>

      <section style={{ marginBottom: "3rem" }}>
        <h2 style={{ fontSize: "0.75rem", textTransform: "uppercase", letterSpacing: "0.1em", color: "#475569", marginBottom: "1.25rem" }}>
          Evidence-First Zone Tour
        </h2>
        <p style={{ fontSize: "0.78rem", color: "#64748b", marginBottom: "1rem" }}>
          Confidence-gradient traversal order (MANIFOLD_ANALYSIS.md §11.4). Visits fully-grounded zones (σ̄ = 1.0) before partially-grounded (σ̄ = 0.5).
        </p>
        <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: "0.4rem" }}>
          {ZONE_CONFIDENCE_ORDER.map((zone, i) => {
            const sigma = m.zoneConfidenceCentroids[zone] ?? 0;
            const color = sigma >= 1.0 ? "#4ade80" : "#facc15";
            return (
              <div key={zone} style={{ display: "flex", alignItems: "center", gap: "0.4rem" }}>
                <div
                  style={{
                    background: "#0f172a",
                    border: `1px solid ${color}44`,
                    borderRadius: "4px",
                    padding: "0.3rem 0.65rem",
                    fontSize: "0.78rem",
                    color,
                  }}
                >
                  <span style={{ color: "#475569", marginRight: "0.35rem", fontSize: "0.65rem" }}>{i + 1}</span>
                  {zone}
                </div>
                {i < ZONE_CONFIDENCE_ORDER.length - 1 && (
                  <span style={{ color: "#334155", fontSize: "0.8rem" }}>→</span>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* ── Organism Memory ──────────────────────────────────────────────── */}
      <section style={{ marginBottom: "3rem" }}>
        <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", marginBottom: "0.4rem" }}>
          <h2 style={{ fontSize: "0.75rem", textTransform: "uppercase", letterSpacing: "0.1em", color: "#475569", margin: 0 }}>
            Organism Memory
          </h2>
          {lm.totalInteractions > 0 && (
            <button
              type="button"
              onClick={reset}
              style={{
                fontSize: "0.65rem",
                fontFamily: "monospace",
                textTransform: "uppercase",
                letterSpacing: "0.08em",
                color: "#475569",
                background: "transparent",
                border: "1px solid #1e293b",
                borderRadius: "3px",
                padding: "2px 8px",
                cursor: "pointer",
              }}
            >
              reset epigenome
            </button>
          )}
        </div>
        <p style={{ fontSize: "0.78rem", color: "#64748b", marginBottom: "1.25rem" }}>
          Accumulated interaction tensors — the epigenome. Persists across sessions via localStorage.
          See <code style={{ color: "#94a3b8" }}>hebbianAdapter.ts</code> for the derivation model.
        </p>

        {/* Interaction count */}
        <div style={{ display: "flex", alignItems: "baseline", gap: "0.75rem", marginBottom: "1.5rem", borderLeft: "3px solid #334155", paddingLeft: "1rem" }}>
          <span style={{ fontSize: "1.05rem", fontWeight: 600, color: "#e2e8f0" }}>Total Interactions</span>
          <span style={{ fontSize: "1.4rem", fontWeight: 700, color: lm.totalInteractions === 0 ? "#475569" : "#7dd3fc", fontVariantNumeric: "tabular-nums" }}>
            {lm.totalInteractions}
          </span>
          {lm.totalInteractions === 0 && (
            <span style={{ fontSize: "0.72rem", color: "#475569", fontStyle: "italic" }}>virgin state — no learning recorded yet</span>
          )}
          {lm.isAdapted && (
            <span style={{ fontSize: "0.7rem", textTransform: "uppercase", letterSpacing: "0.08em", color: "#4ade80", border: "1px solid #4ade80", borderRadius: "3px", padding: "1px 5px" }}>
              adapted
            </span>
          )}
        </div>

        {/* Visit intensity heatmap */}
        {lm.totalInteractions > 0 && (
          <div style={{ marginBottom: "1.5rem" }}>
            <div style={{ fontSize: "0.72rem", color: "#475569", marginBottom: "0.5rem", textTransform: "uppercase", letterSpacing: "0.08em" }}>
              Organelle Visit Intensity (σ, sqrt-scaled)
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(160px, 1fr))", gap: "0.4rem" }}>
              {Object.entries(lm.organelleVisitIntensity)
                .sort(([, a], [, b]) => b - a)
                .map(([id, intensity]) => {
                  const barWidth = Math.round(intensity * 100);
                  const barColor = intensity > 0.7 ? "#7dd3fc" : intensity > 0.35 ? "#38bdf8" : "#1e3a5f";
                  return (
                    <div key={id} style={{ background: "#0f172a", border: "1px solid #1e293b", borderRadius: "4px", padding: "0.4rem 0.6rem" }}>
                      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "0.25rem" }}>
                        <span style={{ fontSize: "0.7rem", color: "#94a3b8" }}>{id}</span>
                        <span style={{ fontSize: "0.7rem", color: barColor, fontVariantNumeric: "tabular-nums" }}>{intensity.toFixed(2)}</span>
                      </div>
                      <div style={{ height: "3px", background: "#1e293b", borderRadius: "2px" }}>
                        <div style={{ height: "100%", width: `${barWidth}%`, background: barColor, borderRadius: "2px", transition: "width 0.5s ease" }} />
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>
        )}

        {/* Emergent biophoton pairs */}
        {Object.keys(lm.learnedBiophotonWeights).length > 0 && (
          <div style={{ marginBottom: "1.5rem" }}>
            <div style={{ fontSize: "0.72rem", color: "#475569", marginBottom: "0.5rem", textTransform: "uppercase", letterSpacing: "0.08em" }}>
              Emergent Co-activation Links (Hebbian, top pairs)
            </div>
            {Object.entries(lm.learnedBiophotonWeights)
              .sort(([, a], [, b]) => b - a)
              .slice(0, 6)
              .map(([pair, weight]) => {
                const [a, b] = parsePairKey(pair);
                const barColor = weight > 0.7 ? "#a78bfa" : "#6d28d9";
                return (
                  <div key={pair} style={{ display: "flex", alignItems: "center", gap: "0.75rem", background: "#0f172a", border: "1px solid #1e3a5f", borderRadius: "6px", padding: "0.5rem 0.85rem", marginBottom: "0.35rem" }}>
                    <span style={{ color: "#7dd3fc", fontSize: "0.82rem", fontWeight: 600 }}>{a}</span>
                    <span style={{ color: "#475569", fontSize: "0.8rem" }}>⟷</span>
                    <span style={{ color: "#7dd3fc", fontSize: "0.82rem", fontWeight: 600 }}>{b}</span>
                    <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: "0.5rem" }}>
                      <div style={{ width: "48px", height: "3px", background: "#1e293b", borderRadius: "2px" }}>
                        <div style={{ height: "100%", width: `${Math.round(weight * 100)}%`, background: barColor, borderRadius: "2px" }} />
                      </div>
                      <span style={{ fontSize: "0.68rem", color: barColor, fontVariantNumeric: "tabular-nums" }}>{weight.toFixed(2)}</span>
                    </div>
                  </div>
                );
              })}
          </div>
        )}

        {/* Confidence boosts */}
        {Object.keys(lm.confidenceBoosts).length > 0 && (
          <div style={{ marginBottom: "1.5rem" }}>
            <div style={{ fontSize: "0.72rem", color: "#475569", marginBottom: "0.5rem", textTransform: "uppercase", letterSpacing: "0.08em" }}>
              Substrate σ Boosts (max +0.15 — attention evidence, not verification)
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(180px, 1fr))", gap: "0.4rem" }}>
              {Object.entries(lm.confidenceBoosts)
                .sort(([, a], [, b]) => b - a)
                .map(([id, boost]) => (
                  <div key={id} style={{ background: "#0f172a", border: "1px solid #1e3a5f", borderRadius: "4px", padding: "0.4rem 0.6rem" }}>
                    <div style={{ display: "flex", justifyContent: "space-between" }}>
                      <span style={{ fontSize: "0.7rem", color: "#94a3b8" }}>{id}</span>
                      <span style={{ fontSize: "0.7rem", color: "#facc15", fontVariantNumeric: "tabular-nums" }}>+{boost.toFixed(3)}</span>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        )}

        {/* Zone × TriadPhase exploration tensor */}
        {Object.keys(lm.zonePhaseIntensity).length > 0 && (
          <div style={{ marginBottom: "1.5rem" }}>
            <div style={{ fontSize: "0.72rem", color: "#475569", marginBottom: "0.5rem", textTransform: "uppercase", letterSpacing: "0.08em" }}>
              Zone × Triad-Phase Exploration (Q<sup>z,p</sup> marginal — P→A→E per zone)
            </div>
            <p style={{ fontSize: "0.72rem", color: "#334155", marginBottom: "0.75rem" }}>
              2D projection of the Q<sup>z,p,s</sup> rank-3 tensor onto (zone, phase). P = zone navigation; A = click-lock within zone.
            </p>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", gap: "0.5rem" }}>
              {Object.entries(lm.zonePhaseIntensity)
                .sort(([, a], [, b]) => (b.perception + b.affect) - (a.perception + a.affect))
                .map(([zoneId, phases]) => (
                  <div key={zoneId} style={{ background: "#0f172a", border: "1px solid #1e293b", borderRadius: "5px", padding: "0.5rem 0.7rem" }}>
                    <div style={{ fontSize: "0.7rem", color: "#64748b", marginBottom: "0.4rem", fontWeight: 600 }}>{zoneId}</div>
                    {(["perception", "affect", "expression"] as const).map((phase) => {
                      const val = phases[phase];
                      if (val === 0) return null;
                      const phaseColor = phase === "perception" ? "#38bdf8" : phase === "affect" ? "#a78bfa" : "#34d399";
                      return (
                        <div key={phase} style={{ display: "flex", alignItems: "center", gap: "0.4rem", marginBottom: "0.2rem" }}>
                          <span style={{ fontSize: "0.6rem", fontFamily: "monospace", color: phaseColor, width: "64px", flexShrink: 0 }}>{phase}</span>
                          <div style={{ flex: 1, height: "3px", background: "#1e293b", borderRadius: "2px" }}>
                            <div style={{ height: "100%", width: `${Math.round(val * 100)}%`, background: phaseColor, borderRadius: "2px", opacity: 0.8 }} />
                          </div>
                          <span style={{ fontSize: "0.6rem", color: phaseColor, fontVariantNumeric: "tabular-nums", width: "28px", textAlign: "right" }}>
                            {val.toFixed(2)}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                ))}
            </div>
          </div>
        )}

        {lm.totalInteractions === 0 && (
          <div style={{ background: "#0f172a", border: "1px solid #1e293b", borderRadius: "6px", padding: "1rem 1.25rem", fontSize: "0.8rem", color: "#475569" }}>
            The organism has not yet been observed. Click organelles and substrate nodes in the
            Explorer to begin accumulating the epigenome. Learning persists across sessions.
          </div>
        )}
      </section>

      <footer style={{ borderTop: "1px solid #1e293b", paddingTop: "1rem", fontSize: "0.72rem", color: "#334155" }}>
        Hidden developer surface · /metrics · Cell OS · Manifold Analysis rev 2 · epigenome v1
      </footer>
    </div>
  );
}
